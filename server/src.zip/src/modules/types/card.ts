// type TProductMenu = {
//   id: number;
//   available: boolean;
//   name: string;
//   meta_title: string;
//   price: number;
//   description: string | null;
//   meta_description: string | null;
//   waiting: number;
//   src: string;
// };

// type TProductsMenu = Array<TProductMenu>;

// type TProductsCategoryMenu = {
//   category: string;
//   icon: string;
//   products: TProductsMenu;
// };

// type TAllProductsCategoryMenu = Array<TProductsCategoryMenu>;

// type TCardSearchProductMenu = {
//   id: number;
//   rank: number;
//   rank_title: number;
//   rank_description: number;
//   name: string;
//   src: string;
//   category: string;
//   description: string;
// }

// type TCardsSearchProductMenu = Array<TCardSearchProductMenu>;
