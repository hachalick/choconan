export const allCategory = [
  {
    category: 'قهوه',
    icon: '/coffee.png',
  },
  {
    category: 'چای',
    icon: '/tea.png',
  },
  {
    category: 'دمنوش',
    icon: '/herbal-tea.png',
  },
  {
    category: 'نوشیدنی گرم',
    icon: '/hot-drink.png',
  },
  {
    category: 'کیک',
    icon: '/cake.png',
  },
  {
    category: 'شکلات',
    icon: '/candy.png',
  },
  {
    category: 'نان',
    icon: '/bread.png',
  },
  {
    category: 'آیس',
    icon: '/iced-coffee.png',
  },
  {
    category: 'شیک',
    icon: '/milkshake.png',
  },
  {
    category: 'اسموتی',
    icon: '/smoothie.png',
  },
  {
    category: 'فراپه',
    icon: '/frappe.png',
  },
  {
    category: 'موکتل',
    icon: '/mocktail.png',
  },
  {
    category: 'نوشیدنی سرد',
    icon: '/cool-drink.png',
  },
  {
    category: 'کوکی',
    icon: '/cookie.png',
  },
  {
    category: 'شیرینی',
    icon: '/cupcake.png',
  },
  {
    category: 'صبحانه',
    icon: '/breakfast.png',
  },
  {
    category: 'سالاد',
    icon: '/salad.png',
  },
  {
    category: 'ساندویچ',
    icon: '/sandwich.png',
  },
  {
    category: 'پاستا',
    icon: '/spaguetti.png',
  },
  {
    category: "انرژی زا",
    icon: "/energy-drink.png",
  },
  {
    category: "نوشابه",
    icon: "/tipple.png",
  },
];
