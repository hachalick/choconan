export const allCategoryVideos = [
    {
      category: 'aparat',
    },
  ];
  