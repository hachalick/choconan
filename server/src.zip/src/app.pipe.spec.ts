import { FileExcelValidationPipe } from './app.pipe';

describe('APipe', () => {
  it('should be defined', () => {
    expect(new FileExcelValidationPipe()).toBeDefined();
  });
});
