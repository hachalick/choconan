export class SeenLicensePlate {
    id: number;
    licensePlate: string;
  }
  